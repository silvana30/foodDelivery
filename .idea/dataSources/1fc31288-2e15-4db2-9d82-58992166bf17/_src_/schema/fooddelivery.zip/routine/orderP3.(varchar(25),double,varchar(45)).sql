CREATE PROCEDURE orderP3(IN username VARCHAR(25), IN totalPrice DOUBLE, IN paymentType VARCHAR(45))
  BEGIN
	
  #set @aux=GETDATE();
  set @aux2=(Select address from user where username like username);
  set @aux3=(Select idUser from user where username like username);

#update orderP set date=currdate();
INSERT INTO orderP ( idClient  , address , totalPrice , paymentType  )
VALUES (@aux3,@aux2,totalPrice,paymentType);




 END;
