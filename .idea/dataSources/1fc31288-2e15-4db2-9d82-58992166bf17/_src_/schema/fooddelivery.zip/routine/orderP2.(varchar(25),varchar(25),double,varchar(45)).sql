CREATE PROCEDURE orderP2(IN username VARCHAR(25), IN date VARCHAR(25), IN totalPrice DOUBLE, IN paymentType VARCHAR(45))
  BEGIN
	
  #set @aux=GETDATE();
  set @aux2=(Select address from user where username = username);
  set @aux3=(Select idUser from user where username = username);

#update orderP set date=currdate();
INSERT INTO orderP ( idClient , date , address , totalPrice , paymentType  )
VALUES (aux3,date,aux2,totalPrice,paymentType);




 END;
