CREATE PROCEDURE orderPROC(IN username    VARCHAR(25), IN date DATETIME, IN address VARCHAR(80),
                           IN totalPrice  VARCHAR(45), IN paymentType VARCHAR(45))
  BEGIN
	
  set @aux=(Select date from user where username = username);
  set @aux2=(Select address from user where username = username);
  set @aux3=(Select idUser from user where username = username);


INSERT INTO orderP ( idClient , date , address , totalPrice , paymentType  )
VALUES (aux3,aux,aux2,totalPrice,paymentType);




 END;
